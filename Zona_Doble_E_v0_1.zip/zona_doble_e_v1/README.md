# Zona Doble E — Prototipo v0.1

Primer prototipo visual de la aplicación.

## Incluye
- Inicio mediante código de acceso (simulado).
- Mapa visual estilo claro.
- Usuarios con marcadores.
- Ficha de usuario: nombre, teléfono, vehículo, placas y grupo.
- Botón de ubicación ON/OFF.
- Botón de emergencia y estado rojo.
- Pestañas Mapa / Usuarios / Perfil.
- Panel de Administración.
- Diseño blanco, negro y rojo.

## Próxima etapa
Conectar:
1. Firebase Authentication.
2. Firestore para usuarios, grupos y roles.
3. Geolocalización real en segundo plano según permisos del sistema.
4. Google Maps o mapa equivalente.
5. Notificaciones push para emergencias.
6. Códigos de acceso reales.
7. Roles Administrador / Subadministrador / Usuario.
8. Historial de emergencias y auditoría.

## Cómo probar
1. Instala Flutter 3.x.
2. Crea un proyecto vacío con `flutter create zona_doble_e`.
3. Sustituye `pubspec.yaml` y `lib/main.dart` por los archivos de esta carpeta.
4. Ejecuta `flutter pub get`.
5. Ejecuta `flutter run`.

Este prototipo no transmite ubicaciones reales todavía; los marcadores son datos de demostración.
